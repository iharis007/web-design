<div class="panel panel-default">
    <div class="panel-heading"> <span class="glyphicon glyphicon-list-alt"></span><b>Latest Updates</b></div>
        <div class="panel-body">
            <ul class="demo1">
            <li class="news-item">
            <table cellpadding="4">
            <tr>
            <td><img src="images/1.jpg" width="60" class="img-circle" /></td>
            <td>IEEE event to be organised next week... <a href="#">Read more...</a></td>
            </tr>
            </table>
            </li>
            <li class="news-item">
            <table cellpadding="4">
            <tr>
            <td><img src="images/2.png" width="60" class="img-circle" /></td>
            <td> 8th Annual IEEE Communication society meet and seminar ... <a href="#">Read more...</a></td>
            </tr>
            </table>
            </li>
            <li class="news-item">
            <table cellpadding="4">
            <tr>
            <td><img src="images/3.gif" width="60" class="img-circle" /></td>
            <td> IEEE Consumer Electronics Society meet next week... <a href="#">Read more...</a></td>
            </tr>
            </table>
            </li>
            <li class="news-item">
            <table cellpadding="4">
            <tr>
            <td><img src="images/4.jpg" width="60" class="img-circle" /></td>
            <td> IEEE International Conference on Communications ... <a href="#">Read more...</a></td>
            </tr>
            </table>
             </li>
             <li class="news-item">
            <table cellpadding="4">
            <tr>
            <td><img src="images/5.jpg" width="60" class="img-circle" /></td>
             <td> IEEE Robotics Society is organising an International Competition... <a href="#">Read more...</a></td>
             </tr>
             </table>
             </li>
               <li class="news-item">
               <table cellpadding="4">
              <tr>
               <td><img src="images/6.png" width="60" class="img-circle" /></td>
              <td> Andoid Workshop for students... <a href="#">Read more...</a></td>
             </tr>
              </table>
              </li>
               <li class="news-item">
              <table cellpadding="4">
             <tr>
            <td><img src="images/7.png" width="60" class="img-circle" /></td>
               <td>Open source development event... <a href="#">Read more...</a></td>
             </tr>
               </table>
               </li>
               </ul>
                </div>
            </div>
