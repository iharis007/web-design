<?php

// Database Constants
define("DB_SERVER", "localhost");
define("DB_USER", "root");
define("DB_PASS", "singh1150");
define("DB_NAME", "ieee");

?>